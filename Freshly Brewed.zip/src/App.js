import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import DeleteAccountPage from "./pages/DeleteAccountPage";
import UserInterestPage2 from "./pages/UserInterestPage2";
import EmptyWishlistPage from "./pages/EmptyWishlistPage";
import PrivacyPage from "./pages/PrivacyPage";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/user-interest-page2":
        title = "";
        metaDescription = "";
        break;
      case "/emptywishlistpage":
        title = "";
        metaDescription = "";
        break;
      case "/privacy-page":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<DeleteAccountPage />} />
      <Route path="/user-interest-page2" element={<UserInterestPage2 />} />
      <Route path="/emptywishlistpage" element={<EmptyWishlistPage />} />
      <Route path="/privacy-page" element={<PrivacyPage />} />
    </Routes>
  );
}
export default App;
