import styles from "./DeleteAccountPage.module.css";

const DeleteAccountPage = () => {
  return <div className={styles.deleteAccountPage} />;
};

export default DeleteAccountPage;
