import styles from "./PrivacyPage.module.css";

const PrivacyPage = () => {
  return <div className={styles.privacyPage} />;
};

export default PrivacyPage;
