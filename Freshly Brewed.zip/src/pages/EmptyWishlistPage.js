import styles from "./EmptyWishlistPage.module.css";

const EmptyWishlistPage = () => {
  return <div className={styles.emptyWishlistPage} />;
};

export default EmptyWishlistPage;
