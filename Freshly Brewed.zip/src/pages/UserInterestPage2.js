import styles from "./UserInterestPage2.module.css";

const UserInterestPage2 = () => {
  return <div className={styles.userInterestPage2} />;
};

export default UserInterestPage2;
